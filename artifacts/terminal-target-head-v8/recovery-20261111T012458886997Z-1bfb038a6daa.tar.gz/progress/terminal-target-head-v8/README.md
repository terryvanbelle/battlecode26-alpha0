# V8 development transfer

Valid benchmark games: 768/768. No automatic promotion.

![Opponent-map W/L/D](comparison.png)

![Coverage](coverage.png)

The terminal head is the preregistered candidate; the PUCT head is a matched control. Complete-panel improvement uses ≥5 percentage points score gain, positive paired-map bootstrap lower bound and aggregate zdb nonregression. Fresh-seed confirmation is required for promotion. First-action validation is a separately reported mechanism diagnostic, not a substitute for benchmark improvement.

## Comparisons

```json
{
  "terminal_head": {
    "complete": true,
    "games_per_checkpoint": 256,
    "mean_score_gain": -0.00390625,
    "paired_map_bootstrap_95_interval": [
      -0.02734375,
      0.01953125
    ],
    "per_opponent_score_gain": {
      "CS50Crab_rapierV1": -0.03125,
      "spsquared_TSPAARK_QUALS": 0.125,
      "HugoIngelsson_Xzibit": -0.03125,
      "vibe26b_zdb": 0.0,
      "HugoIngelsson_YokoOno": 0.09375,
      "abcdezyxwv_bestsofar": -0.0625,
      "uravt_Version41": -0.125,
      "IvanGeffner_basic51": 0.0
    },
    "passes_development_improvement_rule": false,
    "automatic_promotion": false,
    "all_map_victory": false,
    "baseline_wins": 82,
    "candidate_wins": 81
  },
  "puct_head": {
    "complete": true,
    "games_per_checkpoint": 256,
    "mean_score_gain": -0.01171875,
    "paired_map_bootstrap_95_interval": [
      -0.05078125,
      0.015625
    ],
    "per_opponent_score_gain": {
      "CS50Crab_rapierV1": 0.03125,
      "spsquared_TSPAARK_QUALS": 0.03125,
      "HugoIngelsson_Xzibit": 0.0,
      "vibe26b_zdb": 0.0,
      "HugoIngelsson_YokoOno": -0.03125,
      "abcdezyxwv_bestsofar": -0.03125,
      "uravt_Version41": -0.09375,
      "IvanGeffner_basic51": 0.0
    },
    "passes_development_improvement_rule": false,
    "automatic_promotion": false,
    "all_map_victory": false,
    "baseline_wins": 82,
    "candidate_wins": 79
  }
}
```

## Independent first-action validation

```json
{
  "complete": true,
  "mean_delta_vs_puct": 0.0,
  "mean_delta_vs_cp2": 0.0,
  "criteria_pass": false
}
```

## Research decision

```json
{
  "complete": true,
  "criteria_pass": false,
  "integrity_verified": true,
  "review_for_expansion": false,
  "automatic_promotion": false,
  "all_map_victory": false,
  "scope": "Precommitted research review rule; no model promotion or all-map victory claim."
}
```
