# Warmstart iteration 1 resume

Verify the archive SHA-256 against its sidecar and every extracted file against SNAPSHOT-MANIFEST.json. Restore into a clean checkout at `/workspace/battlecode26-alpha0`; original absolute paths in plans/evidence are preserved.

This archive preserves cp0/cp1, latest model/optimizer/NumPy and Torch RNG, active replay and its RNG, initialization/prior, plans, raw game transcripts, project-owned source, maps, logs and evaluation evidence. All checkpoint-boundary run-state files are byte-identical to the original unpublished snapshot. Older replay generations and consumed game arrays are omitted with hashes.

Downloaded benchmark source, compiled benchmark/engine classes, vendor engine JARs and JDK files are NOT bundled. Run `bash scripts/bootstrap.sh` in the restored checkout to provision the hash-pinned JDK/engine/Python packages, download benchmarks at the archived manifest commits, and rebuild classes. Verify rebuilt identities against resume.training_runtime and evaluation evidence before resuming a saved plan. The archived setup/fetch scripts, configs/benchmarks.json and external_dependencies metadata preserve pins/hashes.

Resume only when intended with `.venv/bin/python scripts/run_warmstart_experiment.py --target-iteration 2 --hours 2`. No PID/lock/STOP/temp files are restored. No policy promotion or holdout evaluation occurs automatically.
