# Warmstart iteration 2 resume

Verify resume.tar.gz against its sidecar SHA-256 and verify extracted file hashes against SNAPSHOT-MANIFEST.json.

Restore into a clean checkout at the original source root `/workspace/battlecode26-alpha0`. Archive paths are repository-relative. Plans and evidence retain absolute original paths; this exporter does not rebase them. Run the archived hash-pinned bootstrap/setup/fetch scripts to provision Python/JDK/engine and rebuild bridge/benchmark classes; verify recorded runtime hashes. Downloaded benchmark source, compiled classes, engine JARs and JDK files are not bundled. The archive contains the prior dependency, cp0, all model checkpoints, latest optimizer/RNG state, active replay including its RNG, plans, raw game JSON, logs and evaluation evidence. Older replay generations and consumed game NPZ files are omitted with hashes; historical model evaluation remains available, but historical replay rollback is not included. No local files were pruned.

Resume explicitly with `.venv/bin/python scripts/run_warmstart_experiment.py --target-iteration 3 --hours 2`. No STOP, PID, lock or temporary file is restored. Resuming training does not promote the policy.
